const bayes = require('classificator')
const classifier = bayes()
const db = require("helpers/db");
const MissingChild = db.MissingChild;

module.exports.classifyChild = async (found_child) => {
    // fetching all missing children from database
    const missingChilderen = await MissingChild.find({});
    
    missingChilderen.forEach(child => {
        // training classifier with all available missing childrens 
        // classifier.learn('ali, male, 24', 'ALI')
        classifier.learn(`${child.name.toLowercase()}, ${child.gender}, ${child.age}`, child.name.toLowercase())
    });

    // matching the new found child with training data
    const result = classifier.categorize(`${found_child.name.toLowercase()}, ${found_child.gender}, ${found_child.age}`);
    console.log(result)
}