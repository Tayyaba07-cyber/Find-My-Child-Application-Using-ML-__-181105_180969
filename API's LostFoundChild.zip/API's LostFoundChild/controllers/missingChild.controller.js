﻿const express = require("express");

const db = require("helpers/db");
const MissingChild = db.MissingChild;

module.exports = {
  create,
  getAll,
  getById,
  delete: _delete,
};

async function create(req, res, next) {
  const child = new MissingChild(req.body);
  await child.save();
  res.sendSuccessResponse(child);
};

async function getAll(req, res, next) {
  const children = await MissingChild.find();
  res.sendSuccessResponse(children);
};

async function getById(req, res, next) {
  const child = await MissingChild.findById(req.params.id);
  res.sendSuccessResponse(child);
};

async function _delete(req, res, next) {
  await MissingChild.findByIdAndRemove(req.params.id);
};
