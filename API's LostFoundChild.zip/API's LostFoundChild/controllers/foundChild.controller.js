﻿const db = require("helpers/db");
const FoundChild = db.FoundChild;

module.exports = {
  create,
  getAll,
  getById,
  delete: _delete,
};

async function create(req, res, next) {
  const child = new FoundChild(req.body);
  await child.save();
  res.sendSuccessResponse(child);
};

async function getAll(req, res, next) {
  const children = await FoundChild.find();
  res.sendSuccessResponse(children);
};

async function getById(req, res, next) {
  const child = await FoundChild.findById(req.params.id);
  res.sendSuccessResponse(child);
};

async function _delete(req, res, next) {
  await FoundChild.findByIdAndRemove(req.params.id);
};
