﻿const express = require('express');
const router = express.Router();
const userService = require('services/user.service');

module.exports = {
    authenticate,
    register,
    forgetPassword,
    changePassword,
    getAll,
    getById,
    getCurrent,
    update,
    delete: _delete
};

function authenticate(req, res, next) {
    userService.authenticate(req.body)
        .then(user => user ?
            res.sendSuccessResponse(user) :
            res.sendFailureResponse('Email or password is incorrect'))
        .catch(err => next(err));
}

function register(req, res, next) {
    userService.create(req.body)
        .then(() => res.sendSuccessResponse({}))
        .catch(err => next(err));
}

function forgetPassword(req, res, next) {
    userService.forgetPassword(req.body)
        .then(success => success ?
            res.sendSuccessResponse() :
            res.sendFailureResponse('Email is incorrect')
        )
        .catch(err => next(err));
}

function changePassword(req, res, next) {
    userService.changePassword(req.body)
        .then(success => success ?
            res.sendSuccessResponse() :
            res.sendFailureResponse('Password is incorrect')
        )
        .catch(err => next(err));
}

function getAll(req, res, next) {
    userService.getAll()
        .then(users => res.sendSuccessResponse(users))
        .catch(err => next(err));
}

function getCurrent(req, res, next) {
    userService.getById(req.user.sub)
        .then(user => user ? res.sendSuccessResponse(user) : res.sendNotFoundResponse())
        .catch(err => next(err));
}

function getById(req, res, next) {
    userService.getById(req.params.id)
        .then(user => user ? res.sendSuccessResponse(user) : res.sendNotFoundResponse())
        .catch(err => next(err));
}

function update(req, res, next) {
    userService.update(req.params.id, req.body)
        .then(() => res.sendSuccessResponse({}))
        .catch(err => next(err));
}

function _delete(req, res, next) {
    userService.delete(req.params.id)
        .then(() => res.sendSuccessResponse({}))
        .catch(err => next(err));
}