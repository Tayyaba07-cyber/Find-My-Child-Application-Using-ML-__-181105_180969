const express = require("express");
const router = express.Router();
const foundChildController = require("../controllers/foundChild.controller");
const auth = require("helpers/authorization");

// routes
router.post("/", foundChildController.create);
router.get("/", foundChildController.getAll);
router.get("/:id", auth.authorize(), foundChildController.getById);
router.delete("/:id", auth.authorize(), foundChildController.delete);

module.exports = router;
