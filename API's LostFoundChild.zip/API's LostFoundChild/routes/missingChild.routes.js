const express = require("express");
const router = express.Router();
const missingChildController = require("../controllers/missingChild.controller");
const auth = require("helpers/authorization");

// routes
router.post("/", missingChildController.create);
router.get("/", missingChildController.getAll);
router.get("/:id", auth.authorize(), missingChildController.getById);
router.delete("/:id", auth.authorize(), missingChildController.delete);

module.exports = router;
