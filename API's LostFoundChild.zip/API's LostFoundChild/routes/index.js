const express = require("express");
const router = express.Router();

router.use("/users", require("./user.routes"));
router.use("/missing-child", require("./missingChild.routes"));
router.use("/found-child", require("./foundChild.routes"));

module.exports = router;
