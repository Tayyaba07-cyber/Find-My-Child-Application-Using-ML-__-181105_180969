const express = require("express");
const router = express.Router();
const userscontroller = require('controllers/users.controller');
const auth = require('helpers/authorization');
const { ROLES } = require('constants/index')

// routes
router.post('/authenticate', userscontroller.authenticate);
router.post('/register', userscontroller.register);
router.post('/forgetPassword', userscontroller.forgetPassword);
router.post('/changePassword', userscontroller.changePassword);
router.get('/', auth.authorize(), userscontroller.getAll);
router.get('/current', auth.authorize(), userscontroller.getCurrent);
router.get('/:id', auth.authorize(), userscontroller.getById);
router.put('/:id', auth.authorize(), userscontroller.update);
router.delete('/:id', auth.authorize(), userscontroller.delete);

module.exports = router;
