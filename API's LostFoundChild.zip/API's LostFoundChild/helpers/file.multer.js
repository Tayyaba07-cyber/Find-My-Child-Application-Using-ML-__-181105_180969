const multer = require('multer');
const uuid = require('uuid');
const path = require('path');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname === "task-images") {
            cb(null, './files/images/tasks/')
        }
        else if (file.fieldname === "contractor") {
            cb(null, './files/images/contractors');
        }
        else if (file.fieldname === "customer") {
            cb(null, './files/images/customers/')
        }
        else if (file.fieldname === "certificate") {
            cb(null, './files/certificates')
        }
    },
    filename: function (req, file, cb) {
        cb(null, uuid.v4() + path.extname(file.originalname))
    }
})

function uploadTaskImage(req, res, next) {
    try {
        var upload = multer({ storage: storage }).any();

        upload(req, res, (err) => {
            if (!err) {
                var filePaths = req.files.map((f, i) => {
                    return f.path;
                });
                res.sendSuccessResponse({ filePaths });
            }
            else {
                console.log(err.message)
                res.sendFailureResponse({});
            }
        })
    }
    catch (exp) {
        console.log(exp)
        res.sendFailureResponse({});
    }
}
var upload = multer({ storage: storage })
module.exports = {
    uploadTaskImage
}