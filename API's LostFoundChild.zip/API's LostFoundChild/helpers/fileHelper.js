const fs = require('fs');
const uuid = require('uuid');

function encode_base64(filename) {
    fs.readFile(path.join(__dirname, filename), function (error, data) {
        if (error) {
            throw error;
        } else {
            //console.log(data);
            var dataBase64 = Buffer.from(data).toString('base64');
            console.log(dataBase64);
            client.write(dataBase64);
        }
    });
}

function base64_decode(base64Image, fileName) {
    fs.writeFileSync(fileName, base64Image);
    console.log('******** File created from base64 encoded string ********');

}

const saveStoreImage = async (base64String) => {
    return saveBase64(base64String, 'store');
}

const saveCustomerImage = async (base64String, image_key) => {
    return new Promise((resolve, reject) => {
        try {
            var data = base64String.replace(/^data:image\/\w+;base64,/, '');
            var buffer = new Buffer.from(data, 'base64');
            var fileName = `${image_key}.jpeg`;
            var filepath = `images/customers/${fileName}`;
            var public_file_path = `/customers/${fileName}`;
            fs.writeFileSync(filepath, buffer);
            return resolve(public_file_path);
        }
        catch (err) {
            return reject(err);
        }
    })
}

const saveTaskImages = async (base64StringList) => {
    return new Promise((resolve, reject) => {
        try {
            var paths = [];
            base64StringList.forEach(image => {
                var data = image.replace(/^data:image\/\w+;base64,/, '');
                var buffer = new Buffer.from(data, 'base64');
                var fileName = `${uuid.v4()}.jpeg`;
                var filepath = `images/task/${fileName}`;
                var public_file_path = `/task/${fileName}`;
                fs.writeFileSync(filepath, buffer);
                paths.push(public_file_path);
            })
            return resolve(paths);
        }
        catch (err) {
            return reject(err);
        }
    })
}

const saveContractorCertificates = async (certificatesList) => {
    return new Promise((resolve, reject) => {
        try {
            var paths = [];
            certificatesList.forEach(docObj => {
                var data = image.replace(/^data:image\/\w+;base64,/, '');
                var buffer = new Buffer.from(data, 'base64');
                var fileName = `${uuid.v4()}.${docObj.mime_type}`;
                var filepath = `images/task/${fileName}`;
                var public_file_path = `/task/${fileName}`;
                fs.writeFileSync(filepath, buffer);
                paths.push(public_file_path);
            })
            return resolve(paths);
        }
        catch (err) {
            return reject(err);
        }
    })
}

const saveContractorImage = async (base64String, image_key) => {
    return new Promise((resolve, reject) => {
        try {
            var data = base64String.replace(/^data:image\/\w+;base64,/, '');
            var buffer = new Buffer.from(data, 'base64');
            var fileName = `${image_key}.jpeg`;
            var filepath = `images/contractors/${fileName}`;
            var public_file_path = `/contractors/${fileName}`;
            fs.writeFileSync(filepath, buffer);
            return resolve(public_file_path);
        }
        catch (err) {
            return reject(err);
        }
    })
}

const saveQueryCustomerImage = async (base64String) => {
    return saveBase64(base64String, 'queryImages');
}

const saveBase64 = async (base64String, directory) => {
    var data = base64String.replace(/^data:image\/\w+;base64,/, '');
    var buffer = new Buffer.from(data, 'base64');
    var uuid = create_UUID();
    var fileName = `${uuid}.jpeg`;
    var filepath = `images/${directory}/${fileName}`;
    var public_file_path = `/${directory}/${fileName}`;
    fs.writeFileSync(filepath, buffer);
    return public_file_path;
}

function create_UUID() {
    var dt = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = (dt + Math.random() * 16) % 16 | 0;
        dt = Math.floor(dt / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
}
module.exports = { saveTaskImages, saveCustomerImage, saveContractorImage }