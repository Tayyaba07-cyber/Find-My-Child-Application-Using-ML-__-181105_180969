const nodemailer = require('nodemailer');
const config = require('config.json');

const sendNewStoreEmail = async (email, password) => {
    var html = `Your email ${email} is registered. User this password <b>${password}</b> to signin.`;
    console.log(html);
    await sendEmail(email, html, 'Store Created');
}

const sendStoreRequestEmail = async (request) => {
    var toEmail = config.request_email
    var html = `<html><head>
    <style>td{border: 1px solid black;}table {border-collapse: collapse;}</style>
    </head><body><p>A new store request has been received.</p>
    <h5>Details:</h5>
    <table style=""><tbody>
    <tr><td>Name</td><td>${request.name}</td></tr>
    <tr><td>Owner Name</td><td>${request.owner_name}</td></tr>
    <tr><td>Location</td><td>${request.location}</td></tr>
    <tr><td>Phone</td><td>${request.phone}</td></tr>
    <tr><td>Email</td><td>${request.email}</td></tr>
    </tbody></table></body></html>`;
    await sendEmail(toEmail, html, 'Store Request');
}

const forgetPasswordEmail = async (email, password) => {
    var html = `Please use this temporary password <b>${password}</b>, to reset your password.`;
    //console.log(html);
    await sendEmail(email, html, 'Forget Password');
}

const sendContactUsEmail = async (email, phone, message) => {

    var html = `You have received a message:<br/>
                <b>Customer Email: </b> ${email}<br/>
                <b>Customer Phone: </b> ${phone}<br/>
                <b>Message: </b> ${message}`;

    await sendEmail(config.support_email, html, 'Contact Us');
}

const sendEmail = async (to, body, subject, from) => {
    try {
        let transporter = nodemailer.createTransport({
            host: config.email_host,
            port: config.email_port,
            secure: false, // true for 465, false for other ports
            auth: {
                user: config.email_user, // generated ethereal user
                pass: config.email_pass, // generated ethereal password
            },
            tls: {
                rejectUnauthorized: false
            },
        });

        // send mail with defined transport object
        let info = await transporter.sendMail({
            from: `Toom <${config.email_user}>`, // sender address
            to: to, // list of receivers
            subject: subject, // Subject line        
            html: body, // html body
        });
        console.log(`Email To:${to}, Response: ${info.response}`);
    }
    catch (err) {
        console.log(`Failed to send email to : ${to}.`);
        console.log(err);
    }
}
module.exports = { sendEmail, sendNewStoreEmail, forgetPasswordEmail, sendStoreRequestEmail, sendContactUsEmail }