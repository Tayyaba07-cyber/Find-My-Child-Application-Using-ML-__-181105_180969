module.exports.ROLES = {
    Customer: 'Customer',
    Contractor: 'Contractor',
    Admin: 'Admin'
};

