require('rootpath')();
const express = require("express");
const http = require('http');
const cors = require("cors");
const helmet = require("helmet");
const errorHandler = require("./helpers/error-handler");
const responseHandler = require("./middlewares/response");
const logger = require('./helpers/logger')('server.js');
const path = require('path');
// config, helpers & middleware
const config = require('config.json');
const app = express();
app.use(cors());
app.use(helmet());
// app.use(bodyParser.urlencoded({ limit: '6mb', extended: true }));
// app.use(bodyParser.json({ limit: '6mb' }));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(responseHandler);

/* registering routes */
app.use("/api", require("./routes/index"));

/* global error handeler*/
app.use(errorHandler);

var dir = path.join(__dirname, 'images');
app.use(express.static(dir));

const server = http.createServer(app);
/* creating server */
server.listen(5001, () => {
    //logger.info(`Server listening on port ${config.server_port}`);
    console.log(`Server listening on port ${config.server_port}`);
    //console.log(`Server listening on port 5001`);

});
