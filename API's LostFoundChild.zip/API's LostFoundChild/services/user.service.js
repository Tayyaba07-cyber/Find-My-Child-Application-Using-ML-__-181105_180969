﻿const config = require('config.json');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('helpers/db');
const emailHelper = require('helpers/email.helper');

const User = db.User;

module.exports = {
    authenticate,
    forgetPassword,
    getAll,
    getById,
    create,
    update,
    delete: _delete,
    forgetPassword,
    changesPassword
};

async function authenticate({ email, password }) {
    const user = await User.findOne({ email });
    if (user && bcrypt.compareSync(password, user.hash)) {
        const token = jwt.sign({ sub: user.id }, config.secret, { expiresIn: '7d' });
        return {
            ...user.toJSON(),
            token
        };
    }
}

async function forgetPassword({ email }) {
    const user = await User.findOne({ email: email });

    if (user) {
        var tempPassword = generatePassword();
        user.hash = bcrypt.hashSync(tempPassword, 10);
        user.is_temp_password = true;
        await user.save();

        await emailHelper.forgetPasswordEmail(email, randomPassword);
        return true;
    }
    throw `Invalid email`;
}

async function changesPassword(params) {
    let { user_id, old_password, new_password } = params;
    const user = await User.findById(user_id);

    if (user) {
        if (bcrypt.compareSync(old_password, user.hash)) {
            user.hash = bcrypt.hashSync(new_password, 10);
            user.is_temp_password = false;
            await user.save();

            return true;
        }
        else {
            throw `invalid old password`;
        }
    }
    throw `Invalid email`;
}

async function getAll() {
    return await User.find();
}

async function getById(id) {
    return await User.findById(id);
}

async function create(userParam) {
    
    // validate
    if (await User.findOne({ email: userParam.email })) {
        throw 'Email "' + userParam.email + '" is already taken';
    }

    const user = new User(userParam);

    // hash password
    if (userParam.password) {
        user.hash = bcrypt.hashSync(userParam.password, 10);
    }

    // save user
    await user.save();
}

async function update(id, userParam) {
    const user = await User.findById(id);

    // validate
    if (!user) throw 'User not found';
    if (user.email !== userParam.email && await User.findOne({ email: userParam.email })) {
        throw 'Email "' + userParam.email + '" is already taken';
    }

    // hash password if it was entered
    if (userParam.password) {
        userParam.hash = bcrypt.hashSync(userParam.password, 10);
    }

    // copy userParam properties to user
    Object.assign(user, userParam);

    await user.save();
}

async function _delete(id) {
    await User.findByIdAndRemove(id);
}

const generatePassword = () => {
    var length = 8,
        charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$&)*/",
        retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
}