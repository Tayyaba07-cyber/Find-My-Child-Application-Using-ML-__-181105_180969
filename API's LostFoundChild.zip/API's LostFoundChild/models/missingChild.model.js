const mongoose = require('mongoose');
const { TASK_STATUSES } = require('constants/index')

const Schema = mongoose.Schema;

const schema = new Schema({
    name: { type: String },
    gender: { type: String },
    age: { type: String },
    gaurdianName: { type: String },   
    gaurdianPhoneNumber: { type: String },   
    dressColor: { type: String },   
    hairColor: { type: String },   
    height: { type: String },   
    reporterPhoneNumber: { type: String },    
    createdDate: { type: Date, default: Date.now },    
});

schema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    }
});

module.exports = mongoose.model('MissingChild', schema);