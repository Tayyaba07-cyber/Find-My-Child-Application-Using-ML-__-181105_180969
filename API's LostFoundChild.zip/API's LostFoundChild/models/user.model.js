const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const schema = new Schema({
    email: { type: String, unique: true, required: true },
    hash: { type: String, required: true },
    role: { type: String, required: true },
    is_temp_password: { Boolean },
    createdDate: { type: Date, default: Date.now },
    customer_id: { type: Schema.Types.ObjectId, ref: 'Customer' },
    contractor_id: { type: Schema.Types.ObjectId, ref: 'Contractor' }
});

schema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
        delete ret.hash;
    }
});

module.exports = mongoose.model('User', schema);