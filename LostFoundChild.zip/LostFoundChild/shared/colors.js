export default {
  primary: "#0084FF",
  grey: "#7F7F7F",
  lightGrey: "#E2E2E2",
  success: "#2ecc71",
  error: "#e74c3c",
};
