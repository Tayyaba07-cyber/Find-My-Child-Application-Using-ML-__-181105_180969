import {StatusBar} from 'react-native';
import * as React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';
import HomeScreen from './screens/HomeScreen'
import MapScreen from './screens/MapScreen'
import ReportScreen from './screens/ReportScreen'
import CreateNewReportScreen from './screens/CreateNewReportScreen'
import HistoryScreen from './screens/HistoryScreen'

const ReportStack = createNativeStackNavigator();

function ReportStackScreen() {
  return (
    <ReportStack.Navigator>
      <ReportStack.Screen name="Report" component={ReportScreen}/>
      <ReportStack.Screen name="NewReport" component={CreateNewReportScreen} options={({ route }) => ({ title: route.params.name })} />
    </ReportStack.Navigator>
  );
}

const HomeStack = createNativeStackNavigator();

function HomeStackScreen() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={HomeScreen}/>
    </HomeStack.Navigator>
  );
}

const MapStack = createNativeStackNavigator();

function MapStackScreen() {
  return (
    <MapStack.Navigator>
      <MapStack.Screen name="Map" component={MapScreen}/>
    </MapStack.Navigator>
  );
}

const HistoryStack = createNativeStackNavigator();

function HistoryStackScreen() {
  return (
    <HistoryStack.Navigator>
      <HistoryStack.Screen name="History" component={HistoryScreen}/>
    </HistoryStack.Navigator>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  StatusBar.setBarStyle( 'dark-content',true)
  StatusBar.setBackgroundColor("#ffffff")
 
  return (
    
    <NavigationContainer>
       <Tab.Navigator
        initialRouteName="Home"
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home';
            } else if (route.name === 'Report') {
              iconName = focused ? 'create' : 'create';
            }else if (route.name === 'Map') {
              iconName = focused ? 'map' : 'map';
            }
            else {
              iconName = focused ? 'time' : 'time';
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
          headerShown: false,
        })}
      >
        <Tab.Screen name="Home" component={HomeStackScreen} />
        <Tab.Screen name="Map" component={MapStackScreen}/>
        <Tab.Screen name="Report" component={ReportStackScreen}/>
        <Tab.Screen name="History" component={HistoryStackScreen}/>
      </Tab.Navigator>
    </NavigationContainer>
  );
};