
import React, { useEffect } from 'react';
import { View, StyleSheet, Button, FlatList, Image, Text, TouchableOpacity, ActivityIndicator} from 'react-native';
import { getFoundChildList, getMissingChildList, BaseURL } from '../Networking/APIManager';

function Item({ item }) {
  return (
    <View style={styles.listItem}>
      <Image source={{uri: BaseURL +'/'+ item.imagePath}}  style={{width:60, height:60,borderRadius:30}} />
      <View style={{alignItems:"center",flex:1}}>
        <Text style={{fontWeight:"bold"}}>{item.name}</Text>
        <Text>{item.gender}</Text>
        <Text>{item.age}</Text>
      </View>
      <TouchableOpacity style={{height:50,width:50, justifyContent:"center",alignItems:"center"}}>
        <Text style={{color:"green", fontWeight:"bold"}}>Call</Text>
      </TouchableOpacity>
    </View>
  );
}

export default function HomeScreen() {
  const [selectedIndex, setSelectedIndex] = React.useState(0);

  const [isLoading, setIsLoading] = React.useState(false);

  const [foundData, setFoundData] = React.useState([]);
  const [missingData, setMissingData] = React.useState([]);

  const handleFoundChildPressed = () => {
    setSelectedIndex(0);
    setIsLoading(true);
    getFoundChildList().then((res) => {
      setIsLoading(false);
      console.log(res);
      setFoundData(res);
    })
  };

  const handleMissingChildPressed = () => {
    setSelectedIndex(1);
    setIsLoading(true);
    getMissingChildList().then((res) => {
      setIsLoading(false);
      console.log(res.payload);
      setMissingData(res.payload);
    })

  };

  useEffect(() => {
    setIsLoading(true);
    getFoundChildList().then((res) => {
      setIsLoading(false);
       console.log(res);
       setFoundData(res);
     });
  }, []);

   return (
    <View style={styles.container}>

      <View style={styles.buttonsContainer}>
              <View style={styles.button1Container}>
                <Button color={selectedIndex==0 ? 'gray' : 'black'} title="Found Children" onPress={() => handleFoundChildPressed()}/>
              </View>
              <View style={styles.button2Container}>
                <Button color={selectedIndex==1 ? 'gray' : 'black'} title="Missing Children" onPress={() => handleMissingChildPressed()}/>
              </View>
      </View>
      
      <FlatList
          style={{flex:1}}
          data={selectedIndex==0 ? foundData : missingData}
          renderItem={({ item }) => <Item item={item}/>}
          keyExtractor={item => item.email}
        />

      {isLoading && (
        <ActivityIndicator
          style={{ position: "absolute", left: 0, right: 0, bottom: 0, top: 0, }}
          size="large"
          color='black'
        />
      )}

    </View>
   )

};


const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    buttonsContainer: {
      flexDirection: 'row',
      justifyContent: 'space-around',
    },
    button1Container: {
        flex: 1,
        marginRight: 3,
        backgroundColor: 'red'
    },
    button2Container: {
        flex: 1,
        marginLeft: 3
    },
    listItem:{
      margin:10,
      padding:10,
      backgroundColor:"#FFF",
      width:"85%",
      flex:1,
      alignSelf:"center",
      flexDirection:"row",
      borderRadius:7
    },
    
  });