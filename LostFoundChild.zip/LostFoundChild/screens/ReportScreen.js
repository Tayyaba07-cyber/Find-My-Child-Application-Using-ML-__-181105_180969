
import * as React from 'react';
import { View, StyleSheet, Button, TouchableOpacity, Text } from 'react-native';



export default function ReportScreen({ navigation }) {
  return (
    <View style={styles.container}>
        <Text style={styles.title}>
        You can report newly found child or report your missing child.
      </Text>
    <View style={styles.buttonsContainer}>
            <View style={styles.button1Container}>
               <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('NewReport', { name: 'Register Me', nextName: 'Report Found Child' })}
                >
               <Text style={styles.btnText}>Report Found Child</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.button2Container}>
            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('NewReport', { name: 'Register Me', nextName: 'Report Missing Child' })}
                >
               <Text style={styles.btnText}>Report Missing Child</Text>
              </TouchableOpacity>
            </View>
    </View>

  </View>
  )
};


const styles = StyleSheet.create({
    container: {
      flex: 1,
      marginTop:51,
      marginLeft:11,
      marginRight:11
    },
    title: {
        fontSize:19,
        margin: 31,
        textAlign: 'center',
        marginVertical: 31,
      },
    buttonsContainer: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      marginHorizontal: 1,
      marginVertical: 31
    },
    button1Container: {
        flex: 1,
        marginRight: 3
    },
    button2Container: {
        flex: 1,
        marginLeft: 3
    },
    button: {
      height: 110,
      alignItems: "center",
      backgroundColor: "black",
      borderRadius: 10,
      padding: 41
    },
  btnText: {
      height: 110,
      color: 'white',
      justifyContent:'center',
      textAlign: "center",
  }
  });