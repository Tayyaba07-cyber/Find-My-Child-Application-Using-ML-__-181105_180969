
import React, { useEffect, useState } from 'react';
import { View, StyleSheet, ActivityIndicator, FlatList, Image, Text, TouchableOpacity} from 'react-native';
import { getFoundChildList, BaseURL } from '../Networking/APIManager';


function Item({ item }) {
  return (
    <View style={styles.listItem}>
      <Image source={{uri: BaseURL +'/'+ item.imagePath}}  style={{width:60, height:60,borderRadius:30}} />
      <View style={{alignItems:"center",flex:1}}>
        <Text style={{fontWeight:"bold"}}>{item.name}</Text>
        <Text>{item.gender}</Text>
        <Text>{item.age}</Text>
      </View>
      <View style={{height:50,width:100, justifyContent:"center",alignItems:"center"}}>
        <Text style={{color:"green", fontWeight:"bold"}}>Founded</Text>
      </View>
    </View>
  );
}


export default function HistoryScreen() {

  const [historyData, setHistoryData] = React.useState([]);

  const [isLoading, setIsLoading] = React.useState(false);

  useEffect(() => {
    setIsLoading(true);
    getFoundChildList().then((res) => {
      setIsLoading(false);
       console.log(res);
       setHistoryData(res);
     });
  }, []);

  return (
    <View style={styles.container}>
      <FlatList
          style={{flex:1}}
          data={historyData}
          renderItem={({ item }) => <Item item={item}/>}
          keyExtractor={item => item.email}
        />

      {isLoading && (
        <ActivityIndicator
          style={{ position: "absolute", left: 0, right: 0, bottom: 0, top: 0, }}
          size="large"
          color='black'
        />
      )}

    </View>
  )
};


const styles = StyleSheet.create({
    container: {
      margin:10,
      flex: 1,
    },
    buttonsContainer: {
      flexDirection: 'row',
      justifyContent: 'space-around',
    },
    button1Container: {
        flex: 1,
        marginRight: 3,
        backgroundColor: 'red'
    },
    button2Container: {
        flex: 1,
        marginLeft: 3
    },
    listItem:{
      margin:10,
      padding:10,
      backgroundColor:"#FFF",
      width:"85%",
      flex:1,
      alignSelf:"center",
      flexDirection:"row",
      borderRadius:7
    },
    
  });