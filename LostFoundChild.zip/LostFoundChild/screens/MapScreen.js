import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Button, ActivityIndicator, Image } from 'react-native';
import MapView from 'react-native-maps';
import { getFoundChildList, getMissingChildList, BaseURL } from '../Networking/APIManager';
import Geolocation from '@react-native-community/geolocation';

export default function MapScreen() {

  const [selectedIndex, setSelectedIndex] = React.useState(0);

  const [isLoading, setIsLoading] = React.useState(false);

  const [foundData, setFoundData] = React.useState([]);
  const [missingData, setMissingData] = React.useState([]);

  const [position, setPosition] = useState({
    latitude: 0,
    longitude: 0,
    latitudeDelta: 0.001,
    longitudeDelta: 0.001,
  });

  const handleFoundChildPressed = () => {
    setSelectedIndex(0);
    setFoundData([]);
    setIsLoading(true);
    getFoundChildList().then((res) => {
      setIsLoading(false);
      console.log(res);
      setFoundData(res);
    })
  };

  const handleMissingChildPressed = () => {
    setSelectedIndex(1);
    setMissingData([]);
    setIsLoading(true);
    getMissingChildList().then((res) => {
      setIsLoading(false);
      console.log(res.payload);
      setMissingData(res.payload);
    })

  };

  useEffect(() => {

    Geolocation.getCurrentPosition((pos) => {
      const crd = pos.coords;
      setPosition({
        latitude: crd.latitude,
        longitude: crd.longitude,
        latitudeDelta: 0.0421,
        longitudeDelta: 0.0421,
      });
    }).catch((err) => {
      console.log(err);
    });

    setFoundData([]);
    setIsLoading(true);
    getFoundChildList().then((res) => {
      setIsLoading(false);
       console.log(res);
       setFoundData(res);
     });
  }, []);

  return (
    <View style ={styles.container}>

    <View style={styles.buttonsContainer}>
              <View style={styles.button1Container}>
                <Button color={selectedIndex==0 ? 'gray' : 'black'} title="Found Children" onPress={() => handleFoundChildPressed()}/>
              </View>
              <View style={styles.button2Container}>
                <Button color={selectedIndex==1 ? 'gray' : 'black'} title="Missing Children" onPress={() => handleMissingChildPressed()}/>
              </View>
      </View>

        <MapView
          style={{flex:1}}
          region={position}
          showsMyLocationButton={true}
          showsUserLocation={true}
        >
          {foundData.map(marker => (
             <MapView.Marker 
              coordinate={{
                latitude: position.latitude,
                longitude: position.longitude
              }}
              title={marker.name}
              >
                    
                <Image source={{uri: BaseURL +'/'+ marker.imagePath}} style={{height: 36, width:36, borderRadius: 18, borderWidth: 2, borderColor: "red" }} />

              </MapView.Marker>

           ))}
        </MapView>

        {isLoading && (
        <ActivityIndicator
          style={{ position: "absolute", left: 0, right: 0, bottom: 0, top: 0, }}
          size="large"
          color='black'
        />
      )}

      </View>
  )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  button1Container: {
      flex: 1,
      marginRight: 3,
      backgroundColor: 'red'
  },
  button2Container: {
      flex: 1,
      marginLeft: 3
  },
  listItem:{
    margin:10,
    padding:10,
    backgroundColor:"#FFF",
    width:"85%",
    flex:1,
    alignSelf:"center",
    flexDirection:"row",
    borderRadius:7
  },
  
});