import React, { MyText, useEffect, useState, useRef } from "react";
import Ionicons from 'react-native-vector-icons/Ionicons';

import Geolocation from '@react-native-community/geolocation';

import {
  SafeAreaView,
  View,
  ScrollView,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  Picker,
  TextInput,
  Text,
  ActivityIndicator
} from "react-native";

import ActionSheet from 'react-native-actionsheet';

import {takeImage} from "../shared/utils";

import { reportFoundChild, reportMissingChild, uploadImage } from "../Networking/APIManager";


export default function CreateNewReportScreen({navigation, route}) {

  const [isLoading, setIsLoading] = React.useState(false);

  const [nameText, onChangenameText] = React.useState('');
  const [genderText, onChangenGenderText] = React.useState('');
  const [ageText, onChangenAgeText] = React.useState('');

  const [fatherNameText, onChangeFatherNameText] = React.useState('');
  const [fatherPhoneText, onChangeFatherPhoneText] = React.useState('');
  const [dressColorText, onChangeDressColorText] = React.useState('');
  const [hairColorText, onChangeHairColorText] = React.useState('');
  const [heightText, onChangeHeightText] = React.useState('');

  const [selectedImage, setSelectedImage] = React.useState(null);

  const [number, onChangeNumber] = React.useState('');

  const [imagePath, onUploadImage] = React.useState('');

  const [position, setPosition] = useState({
    latitude: 0,
    longitude: 0
  });

  let actionSheet = useRef();
  var optionArray = ['Take Picture', 'Choose From Gallery', 'Cancel'];

  const showActionSheet = () => {
    //To show the Bottom ActionSheet
    actionSheet.current.show();
  };

  const validateRegisterNumberData = () => {
   //Check for the Number TextInput
   if (!number.trim()) {
     alert('Please Enter Phone Number');
     return;
   }
   //Checked Successfully
   Alert.alert('Alert','Register successfully.',
   [
     { text: "Next", onPress: () =>  (route.params.nextName == 'Report Found Child') ? navigation.navigate('NewReport', { name: 'Report Found Child', reporterPhone: number}) : navigation.navigate('NewReport', { name: 'Report Missing Child', reporterPhone: number})}
   ],
   {cancelable: false},
  )
 };

 const validateFoundChildData = () => {

   if (selectedImage == null) {
      alert('Please Select or Capture Child\'s Photo');
      return;
    }

    const params = {
      name: nameText,
      gender: genderText, // == 'Male' ? 'M' : 'F',
      age: ageText,
      reporterPhoneNumber: route.params.reporterPhone,
      imagePath: imagePath,
      lat: position.latitude,
      long: position.longitude,
    }

    setIsLoading(true);
    reportFoundChild(params).then((res) => {
      setIsLoading(false);
      console.log(res.payload);
      
       //Checked Successfully
       Alert.alert('Alert','Report submitted successfully.',
       [
        { text: "OK", onPress: () => navigation.goBack()}
        ],
        {cancelable: false},
       )
    })
 };

 const validateMissingChildData = () => {

   if (selectedImage == null) {
      alert('Please Select or Capture Child\'s Photo');
      return;
    }

   if (!fatherPhoneText.trim()) {
     alert('Please Enter Father/Guardian Phone Number');
     return;
   }

   const params = {
    name: nameText,
    gender: genderText, // == 'Male' ? 'M' : 'F',
    age: ageText,
    gaurdianName: fatherNameText,   
    gaurdianPhoneNumber: fatherPhoneText,   
    dressColor: dressColorText,   
    hairColor: hairColorText,   
    height: heightText,   
    reporterPhoneNumber: route.params.reporterPhone,
    imagePath: imagePath,
    lat: position.latitude,
    long: position.longitude,
  }

  setIsLoading(true);

   reportMissingChild(params).then((res) => {

    setIsLoading(false);

    console.log(res.payload);
    
     //Checked Successfully
     Alert.alert('Alert','Report submitted successfully.',
     [
      { text: "OK", onPress: () => navigation.goBack()}
      ],
      {cancelable: false},
     )
    })
 };

 useEffect(() => {

  Geolocation.getCurrentPosition((pos) => {
    const crd = pos.coords;
    setPosition({
      latitude: crd.latitude,
      longitude: crd.longitude
    });
  }).catch((err) => {
    console.log(err);
  });

}, []);


  if (route.params.name == 'Register Me'){
   return (
      <SafeAreaView>
        <ScrollView>
        <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15, marginTop:15}}>
        <Text style={styles.title}>
           For submit report you need to register with you phone number.
        </Text>
         <Text style={{ height: 21 }}>Phone Number*</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangeNumber}
            value={number}
            placeholder="Enter your phone number"
            keyboardType="numeric"
         />
      </View>

        <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
          <TouchableOpacity
           style={styles.button}
           onPress={() => validateRegisterNumberData()}
          >
          <Text style={styles.submitText}>Register</Text>
         </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
  }
  else if (route.params.name == 'Report Found Child'){
    return (
      <SafeAreaView>
        <ScrollView>

      <TouchableOpacity
        style={styles.inputContainer}
        activeOpacity={0.6}
        onPress={showActionSheet}
      >
         {selectedImage ? (
          <Image style={styles.image} source={{ uri: selectedImage }} />
        ) : (
          <View style={styles.center}>
            <Ionicons
              name={Platform.OS === "android" ? "md-camera" : "ios-camera"}
              size={80}
              color="black"
            />
          </View>
        )}

      </TouchableOpacity>

        <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15, marginTop:15}}>
           <Text style={{ height: 21 }}>Name</Text>
           <TextInput
              style={styles.input}
              onChangeText={onChangenameText}
              value={nameText}
              placeholder="Enter child's name (optional)"
           />
        </View>

        <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
           <Text style={{ height: 21 }}>Gender*</Text>
             <View style={styles.input}>
              <Picker placeholder="Select child's gender"
                      style={styles.picker}
                      selectedValue={genderText}
                      onValueChange={(itemValue, itemIndex) => onChangenGenderText(itemValue)}
               >
               <Picker.Item label = "Male" value = "male" />
               <Picker.Item label = "Female" value = "female" />
              </Picker>
            </View>         
        </View>

        <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
           <Text style={{ height: 21 }}>Age</Text>
           <TextInput
              style={styles.input}
              onChangeText={onChangenAgeText}
              value={ageText}
              placeholder="Enter child's age (optional)"
              keyboardType="numeric"
           />
        </View>

        <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
          <TouchableOpacity
           style={styles.button}
           onPress={() => validateFoundChildData()}
          >
          <Text style={styles.submitText}>Submit</Text>
         </TouchableOpacity>
        </View>
      </ScrollView>

      <ActionSheet
          ref={actionSheet}
          // Title of the Bottom Sheet
          title={'Which one do you like ?'}
          // Options Array to show in bottom sheet
          options={optionArray}
          // Define cancel button index in the option array
          // This will take the cancel option in bottom
          // and will highlight it
          cancelButtonIndex={2}
          // Highlight any specific option
          destructiveButtonIndex={2}
          onPress={ async (index) => {
            if (index !== 2) {
              const imageUri = await takeImage(index);
              setSelectedImage(imageUri);

              var photoToUpload = {
                uri: imageUri,
                type: 'image/jpeg',
                name: 'photo.jpg',
               };
              const fileData = new FormData();
              fileData.append('file_attachment', photoToUpload);

              setIsLoading(true);
              uploadImage(fileData).then((res) => {
                setIsLoading(false);
                console.log(res.payload.imageName);
                onUploadImage(res.payload.imageName)
              });
            }
          }}
        />

      {isLoading && (
        <ActivityIndicator
          style={{ position: "absolute", left: 0, right: 0, bottom: 0, top: 0, }}
          size="large"
          color='black'
        />
      )}

    </SafeAreaView>
  );
}
else {

  return (
    <SafeAreaView>
      <ScrollView>

      <TouchableOpacity
        style={styles.inputContainer}
        activeOpacity={0.6}
        onPress={showActionSheet}
      >
         {selectedImage ? (
          <Image style={styles.image} source={{ uri: selectedImage }} />
        ) : (
          <View style={styles.center}>
            <Ionicons
              name={Platform.OS === "android" ? "md-camera" : "ios-camera"}
              size={80}
              color="black"
            />
          </View>
        )}

      </TouchableOpacity>


      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15, marginTop:15}}>
         <Text style={{ height: 21 }}>Name</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangenameText}
            value={nameText}
            placeholder="Enter child's name (optional)"
         />
      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
         <Text style={{ height: 21 }}>Gender*</Text>
         {/* <TextInput
            style={styles.input}
            onChangeText={onChangenGenderText}
            value={genderText}
            placeholder="Enter child's gender"
         /> */}

           <View style={styles.input}>
              <Picker placeholder="Select child's gender"
                      style={styles.picker}
                      selectedValue={genderText}
                      onValueChange={(itemValue, itemIndex) => onChangenGenderText(itemValue)}
               >
               <Picker.Item label = "Male" value = "male" />
               <Picker.Item label = "Female" value = "female" />
              </Picker>
            </View>      

      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
           <Text style={{ height: 21 }}>Age</Text>
           <TextInput
              style={styles.input}
              onChangeText={onChangenAgeText}
              value={ageText}
              placeholder="Enter child's age (optional)"
              keyboardType="numeric"
           />
        </View>


      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
         <Text style={{ height: 21 }}>Father/Guardian Name</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangeFatherNameText}
            value={fatherNameText}
            placeholder="Enter child's father/guardian name (optional)"
         />
      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
         <Text style={{ height: 21 }}>Father/Guardian Phone Number*</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangeFatherPhoneText}
            value={fatherPhoneText}
            placeholder="Enter child's father/guardian phone number"
            keyboardType="numeric"
         />
      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
         <Text style={{ height: 21 }}>Dress Color</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangeDressColorText}
            value={dressColorText}
            placeholder="Enter child's dress color (optional)"
         />
      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
         <Text style={{ height: 21 }}>Hair Color</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangeHairColorText}
            value={hairColorText}
            placeholder="Enter child's hair color (optional)"
         />
      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
         <Text style={{ height: 21 }}>Height</Text>
         <TextInput
            style={styles.input}
            onChangeText={onChangeHeightText}
            value={heightText}
            placeholder="Enter child's height(optional)"
            keyboardType="numeric"
         />
      </View>

      <View style={{flexDirection: 'column', justifyContent: 'flex-start', marginLeft: 21, marginRight: 21, marginBottom:15}}>
        <TouchableOpacity
         style={styles.button}
         onPress={() => validateMissingChildData()}
        >
        <Text style={styles.submitText}>Submit</Text>
       </TouchableOpacity>
      </View>
    </ScrollView>


    <ActionSheet
          ref={actionSheet}
          // Title of the Bottom Sheet
          title={'Which one do you like ?'}
          // Options Array to show in bottom sheet
          options={optionArray}
          // Define cancel button index in the option array
          // This will take the cancel option in bottom
          // and will highlight it
          cancelButtonIndex={2}
          // Highlight any specific option
          destructiveButtonIndex={2}
          onPress={ async (index) => {
            if (index !== 2) {
              const imageUri = await takeImage(index);
              setSelectedImage(imageUri);
            }
          }}
        />

     {isLoading && (
        <ActivityIndicator
          style={{ position: "absolute", left: 0, right: 0, bottom: 0, top: 0, }}
          size="large"
          color='black'
        />
      )}

  </SafeAreaView>
);
     }
};

const styles = StyleSheet.create({
    title: {
        fontSize:19,
        margin: 31,
        textAlign: 'center',
        marginVertical: 31,
      },
  input: {
    height: 45,
    marginTop:5,
    borderWidth: 1,
    padding: 10,
    borderRadius: 10
  },
  picker: {
   height: 25,
 },
  button: {
    height: 45,
    alignItems: "center",
    backgroundColor: "black",
    borderRadius: 10,
    padding: 13
  },
submitText: {
    height: 45,
    color: 'white',
},
inputContainer: {
   alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 21,
    marginBottom: 15,
    height: 130,
    width: 130,
    borderRadius: 65,
    backgroundColor: 'gray',
  },
  center: {
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: "100%",
    height: "100%",
    borderRadius: 65,
  },
  imageText: {
    fontSize: 16,
  }
});