

export const BaseURL = `http://192.168.10.2:5001`;

export const getMissingChildList = () => {
    const URL = BaseURL + `/api/missing-child`;
    return fetch(URL)
            .then((res) => res.json());
}

export const getFoundChildList = async () => {
    const URL = BaseURL + `/api/found-child`;
    try {
      const response = await fetch(URL);
      const json = await response.json();
    //   console.log(json.payload);
      return json.payload;
    } catch (error) {
      console.error(error);
    }
  };

export const reportMissingChild = (params) => {
    const URL = BaseURL + `/api/missing-child`;
    return fetch(URL, {
                       method: 'POST',
                       headers: {
                                Accept: 'application/json',
                                'Content-Type': 'application/json'
                                },
                       body: JSON.stringify(params)
                       })
            .then((res) => res.json());
}

export const reportFoundChild = (params) => {
    const URL = BaseURL + `/api/found-child`;
    return fetch(URL, {
                       method: 'POST',
                       headers: {
                                Accept: 'application/json',
                                'Content-Type': 'application/json'
                                },
                       body: JSON.stringify(params)
                       })
            .then((res) => res.json());
}

export const uploadImage = (formData) => {
    const URL = BaseURL + `/api/upload`;
    return fetch(URL, {
                       method: 'POST',
                       headers: {
                                Accept: 'application/json',
                                'Content-Type': 'multipart/form-data'
                                },
                       body: formData
                       })
            .then((res) => res.json());
}  